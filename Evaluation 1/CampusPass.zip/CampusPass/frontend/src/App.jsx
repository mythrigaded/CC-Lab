import { useEffect, useState } from "react";
import "./App.css";

const EVENT_SERVICE_URL = "http://localhost:3001";
const SEAT_SERVICE_URL = "http://localhost:3002";
const BOOKING_SERVICE_URL = "http://localhost:3003";

function App() {
  const [activeNav, setActiveNav] = useState("Home");

  const [events, setEvents] = useState([]);
  const [bookings, setBookings] = useState([]);

  const [selectedEvent, setSelectedEvent] = useState(null);

  const [studentName, setStudentName] = useState("Akshata");

  const [loadingEvents, setLoadingEvents] = useState(true);
  const [bookingLoading, setBookingLoading] = useState(false);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // =====================================================
  // LOAD EVENTS + REAL SEAT COUNTS
  // =====================================================

  const loadEvents = async () => {
    try {
      setLoadingEvents(true);
      setError("");

      // Get events from Event Service
      const eventResponse = await fetch(
        `${EVENT_SERVICE_URL}/events`
      );

      if (!eventResponse.ok) {
        throw new Error("Unable to load events");
      }

      const eventData = await eventResponse.json();

      // Get real seat count for every event
      const eventsWithSeats = await Promise.all(
        eventData.map(async (event) => {
          try {
            const seatResponse = await fetch(
              `${SEAT_SERVICE_URL}/seats/${event.id}`
            );

            if (!seatResponse.ok) {
              return {
                ...event,
                seats: 0,
                totalSeats: event.seats || 0,
              };
            }

            const seatData = await seatResponse.json();

            return {
              ...event,
              seats: seatData.availableSeats,
              totalSeats: seatData.totalSeats,
            };
          } catch (error) {
            console.error(
              `Seat service error for event ${event.id}:`,
              error
            );

            return {
              ...event,
              seats: event.seats || 0,
              totalSeats: event.seats || 0,
            };
          }
        })
      );

      setEvents(eventsWithSeats);
    } catch (error) {
      console.error("Event loading error:", error);

      setError(
        "Unable to load events. Please check that the event service is running."
      );
    } finally {
      setLoadingEvents(false);
    }
  };

  // =====================================================
  // LOAD BOOKINGS
  // =====================================================

  const loadBookings = async () => {
    try {
      const response = await fetch(
        `${BOOKING_SERVICE_URL}/bookings`
      );

      if (!response.ok) {
        throw new Error("Unable to load bookings");
      }

      const data = await response.json();

      setBookings(data);
    } catch (error) {
      console.error("Booking history error:", error);

      setBookings([]);
    }
  };

  // =====================================================
  // INITIAL LOAD
  // =====================================================

  useEffect(() => {
    loadEvents();
    loadBookings();
  }, []);

  // =====================================================
  // OPEN BOOKING MODAL
  // =====================================================

  const openBooking = async (event) => {
    setMessage("");
    setError("");

    try {
      // Always get latest seat count before opening booking modal
      const response = await fetch(
        `${SEAT_SERVICE_URL}/seats/${event.id}`
      );

      if (!response.ok) {
        throw new Error("Seat information unavailable");
      }

      const seatData = await response.json();

      const updatedEvent = {
        ...event,
        seats: seatData.availableSeats,
        totalSeats: seatData.totalSeats,
      };

      setSelectedEvent(updatedEvent);
    } catch (error) {
      console.error("Seat check error:", error);

      setError(
        "Unable to check seat availability. Please try again."
      );
    }
  };

  // =====================================================
  // CONFIRM BOOKING
  // =====================================================

  const handleBooking = async () => {
    if (!selectedEvent) {
      return;
    }

    if (!studentName.trim()) {
      setError("Please enter your name.");
      return;
    }

    setBookingLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch(
        `${BOOKING_SERVICE_URL}/bookings`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            studentName: studentName.trim(),
            eventId: selectedEvent.id,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Booking failed"
        );
      }

      // -------------------------------------------------
      // GET NEW SEAT COUNT FROM BACKEND RESPONSE
      // -------------------------------------------------

      const remainingSeats =
        data.booking?.remainingSeats;

      // -------------------------------------------------
      // UPDATE EVENT IN FRONTEND
      // -------------------------------------------------

      setEvents((previousEvents) =>
        previousEvents.map((event) =>
          event.id === selectedEvent.id
            ? {
                ...event,
                seats:
                  remainingSeats !== undefined
                    ? remainingSeats
                    : Math.max(event.seats - 1, 0),
              }
            : event
        )
      );

      // -------------------------------------------------
      // UPDATE SELECTED EVENT
      // -------------------------------------------------

      setSelectedEvent((previous) =>
        previous
          ? {
              ...previous,
              seats:
                remainingSeats !== undefined
                  ? remainingSeats
                  : Math.max(previous.seats - 1, 0),
            }
          : null
      );

      // -------------------------------------------------
      // REFRESH BOOKING HISTORY
      // -------------------------------------------------

      await loadBookings();

      // -------------------------------------------------
      // SUCCESS MESSAGE
      // -------------------------------------------------

      setMessage(
        `Booking confirmed! ${
          remainingSeats !== undefined
            ? remainingSeats
            : "Updated"
        } seats remaining.`
      );

      // Close modal after successful booking
      setTimeout(() => {
        setSelectedEvent(null);
      }, 1200);

    } catch (error) {
      console.error("Booking error:", error);

      setError(
        error.message ||
          "Booking failed. Please try again."
      );
    } finally {
      setBookingLoading(false);
    }
  };

  // =====================================================
  // CANCEL BOOKING
  // =====================================================

  const cancelBooking = async (bookingId) => {
    const confirmCancel = window.confirm(
      "Are you sure you want to cancel this booking?"
    );

    if (!confirmCancel) {
      return;
    }

    try {
      setError("");
      setMessage("");

      const response = await fetch(
        `${BOOKING_SERVICE_URL}/bookings/${bookingId}`,
        {
          method: "DELETE",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message || "Unable to cancel booking"
        );
      }

      setMessage("Booking cancelled successfully.");

      // Refresh bookings
      await loadBookings();

      // IMPORTANT:
      // Refresh real seat counts after cancellation
      await loadEvents();

    } catch (error) {
      console.error("Cancellation error:", error);

      setError(
        error.message ||
          "Unable to cancel booking."
      );
    }
  };

  // =====================================================
  // NAVIGATION
  // =====================================================

  const goTo = (page) => {
    setActiveNav(page);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });

    setMessage("");
    setError("");
  };

  // =====================================================
  // HOW IT WORKS
  // =====================================================

  const showHowItWorks = () => {
    const section =
      document.getElementById("how-it-works");

    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  // =====================================================
  // RENDER NAVBAR
  // =====================================================

  const renderNavbar = () => {
    return (
      <header className="navbar">
        <div className="navbar-inner">

          <button
            className="brand"
            onClick={() => goTo("Home")}
          >
            <div className="brand-mark">
              CP
            </div>

            <div>
              <h1>CampusPass</h1>
              <span>
                Campus events, simplified.
              </span>
            </div>
          </button>

          <nav>
            <button
              className={
                activeNav === "Home"
                  ? "nav-link active"
                  : "nav-link"
              }
              onClick={() => goTo("Home")}
            >
              Home
            </button>

            <button
              className={
                activeNav === "Events"
                  ? "nav-link active"
                  : "nav-link"
              }
              onClick={() => goTo("Events")}
            >
              Events
            </button>

            <button
              className={
                activeNav === "My Bookings"
                  ? "nav-link active"
                  : "nav-link"
              }
              onClick={() => goTo("My Bookings")}
            >
              My Bookings
            </button>
          </nav>

          <div className="nav-actions">

            <button className="notification-btn">
              ♢
            </button>

            <div className="profile">
              <div className="avatar">
                A
              </div>

              <div className="profile-info">
                <strong>Akshata</strong>
                <span>Student</span>
              </div>

              <span className="chevron">
                ⌄
              </span>
            </div>

          </div>

        </div>
      </header>
    );
  };

  // =====================================================
  // RENDER HOME
  // =====================================================

  const renderHome = () => {
    const featuredEvent =
      events.find((event) => event.id === 1) ||
      events[0];

    return (
      <>
        {/* HERO */}

        <section className="hero-section">

          <div className="hero-content">

            <div className="hero-badge">
              <span className="live-dot"></span>
              CAMPUS LIFE, CONNECTED
            </div>

            <h2>
              Discover what's
              <span> happening.</span>
            </h2>

            <p>
              Find campus events, reserve your seat
              and keep all your bookings in one place.
            </p>

            <div className="hero-actions">

              <button
                className="primary-btn"
                onClick={() => goTo("Events")}
              >
                Explore Events
                <span>→</span>
              </button>

              <button
                className="secondary-btn"
                onClick={showHowItWorks}
              >
                How it works
              </button>

            </div>

          </div>

          {/* HERO EVENT CARD */}

          {featuredEvent && (
            <div className="hero-visual">

              <div className="visual-card main-card">

                <div className="card-top">
                  <span>UPCOMING EVENT</span>
                  <span className="status">
                    ● LIVE
                  </span>
                </div>

                <div className="event-date">
                  <strong>
                    {featuredEvent.date?.split(" ")[0]}
                  </strong>

                  <span>
                    {featuredEvent.date?.split(" ")[1]}
                  </span>
                </div>

                <h3>
                  {featuredEvent.title}
                </h3>

                <div className="event-meta">
                  <span>
                    ◷ {featuredEvent.time}
                  </span>

                  <span>
                    ⌖ {featuredEvent.venue}
                  </span>
                </div>

                <div className="seat-progress">

                  <div className="progress-label">
                    <span>
                      Seats available
                    </span>

                    <strong>
                      {featuredEvent.seats} /{" "}
                      {featuredEvent.totalSeats}
                    </strong>
                  </div>

                  <div className="progress-bar">
                    <div
                      style={{
                        width: `${
                          featuredEvent.totalSeats
                            ? Math.max(
                                0,
                                Math.min(
                                  100,
                                  (featuredEvent.seats /
                                    featuredEvent.totalSeats) *
                                    100
                                )
                              )
                            : 0
                        }%`,
                      }}
                    />
                  </div>

                </div>

                <button
                  className="card-book-btn"
                  onClick={() =>
                    openBooking(featuredEvent)
                  }
                  disabled={featuredEvent.seats <= 0}
                >
                  {featuredEvent.seats > 0
                    ? "Reserve your seat"
                    : "Sold out"}

                  <span>→</span>
                </button>

              </div>

              <div className="floating-card floating-one">
                <span className="floating-icon">
                  ✓
                </span>

                <div>
                  <strong>
                    Real-time booking
                  </strong>

                  <small>
                    Live seat availability
                  </small>
                </div>
              </div>

              <div className="floating-card floating-two">
                <strong>
                  {featuredEvent.seats}
                </strong>

                <span>
                  seats left
                </span>
              </div>

            </div>
          )}

        </section>

        {/* STATS */}

        <section className="stats-section">

          <div className="stat">
            <strong>24+</strong>
            <span>Events this month</span>
          </div>

          <div className="stat">
            <strong>1,200+</strong>
            <span>Students connected</span>
          </div>

          <div className="stat">
            <strong>98%</strong>
            <span>Booking success rate</span>
          </div>

          <div className="stat">
            <strong>3</strong>
            <span>Services working together</span>
          </div>

        </section>

        {/* EVENTS PREVIEW */}

        <section className="events-section">

          <div className="section-heading">

            <div>
              <span className="section-label">
                DISCOVER
              </span>

              <h2>
                Upcoming events
              </h2>

              <p>
                Something interesting is always
                happening on campus.
              </p>
            </div>

            <button
              className="view-all"
              onClick={() => goTo("Events")}
            >
              View all events →
            </button>

          </div>

          {renderEventGrid(3)}

        </section>

        {renderHowItWorks()}
      </>
    );
  };

  // =====================================================
  // EVENT GRID
  // =====================================================

  const renderEventGrid = (limit = events.length) => {

    if (loadingEvents) {
      return (
        <div style={{ padding: "30px 0" }}>
          Loading events...
        </div>
      );
    }

    if (events.length === 0) {
      return (
        <div style={{ padding: "30px 0" }}>
          No events available.
        </div>
      );
    }

    return (
      <div className="events-grid">

        {events.slice(0, limit).map((event) => (

          <article
            className="event-card"
            key={event.id}
          >

            <div className="event-card-image">

              <span>
                {event.category}
              </span>

              <div className="date-box">

                <strong>
                  {event.date?.split(" ")[0]}
                </strong>

                <small>
                  {event.date?.split(" ")[1]}
                </small>

              </div>

            </div>

            <div className="event-card-body">

              <h3>
                {event.name || event.title}
              </h3>

              <p>
                {event.description}
              </p>

              <div className="event-details">

                <span>
                  ◷ {event.time}
                </span>

                <span>
                  ⌖ {event.venue}
                </span>

              </div>

              <div className="card-footer">

                <div>
                  <strong>
                    {event.seats}
                  </strong>

                  <span>
                    {" "}
                    seats available
                  </span>
                </div>

                <button
                  onClick={() =>
                    openBooking(event)
                  }
                  disabled={event.seats <= 0}
                >
                  {event.seats > 0
                    ? "Book →"
                    : "Sold out"}
                </button>

              </div>

            </div>

          </article>

        ))}

      </div>
    );
  };

  // =====================================================
  // EVENTS PAGE
  // =====================================================

  const renderEventsPage = () => {
    return (
      <section className="events-section">

        <div className="section-heading">

          <div>
            <span className="section-label">
              CAMPUS EVENTS
            </span>

            <h2>
              Explore events
            </h2>

            <p>
              Browse all upcoming events and
              reserve your seat.
            </p>
          </div>

        </div>

        {renderEventGrid()}

      </section>
    );
  };

  // =====================================================
  // MY BOOKINGS
  // =====================================================

  const renderBookingsPage = () => {
    return (
      <section className="events-section">

        <div className="section-heading">

          <div>
            <span className="section-label">
              YOUR ACTIVITY
            </span>

            <h2>
              My Bookings
            </h2>

            <p>
              View and manage your event bookings.
            </p>
          </div>

        </div>

        {bookings.length === 0 ? (

          <div
            style={{
              padding: "50px",
              textAlign: "center",
              border: "1px solid #e8e8ef",
              borderRadius: "18px",
            }}
          >
            <h3>
              No bookings yet
            </h3>

            <p>
              Explore events and reserve your
              first seat.
            </p>

            <button
              className="primary-btn"
              onClick={() => goTo("Events")}
            >
              Explore Events →
            </button>
          </div>

        ) : (

          <div className="events-grid">

            {bookings.map((booking) => (

              <article
                className="event-card"
                key={booking.id}
              >

                <div className="event-card-image">

                  <span>
                    BOOKING CONFIRMED
                  </span>

                  <div className="date-box">
                    <strong>✓</strong>
                    <small>
                      Confirmed
                    </small>
                  </div>

                </div>

                <div className="event-card-body">

                  <h3>
                    {booking.eventName}
                  </h3>

                  <p>
                    Booking made by{" "}
                    <strong>
                      {booking.studentName}
                    </strong>
                  </p>

                  <div className="event-details">

                    <span>
                      Booking ID: #{booking.id}
                    </span>

                    <span>
                      Event ID: #{booking.eventId}
                    </span>

                    <span>
                      {new Date(
                        booking.bookingDate
                      ).toLocaleString()}
                    </span>

                  </div>

                  <div className="card-footer">

                    <div>
                      <strong>
                        {booking.remainingSeats}
                      </strong>

                      <span>
                        {" "}
                        seats left
                      </span>
                    </div>

                    <button
                      onClick={() =>
                        cancelBooking(booking.id)
                      }
                    >
                      Cancel
                    </button>

                  </div>

                </div>

              </article>

            ))}

          </div>

        )}

      </section>
    );
  };

  // =====================================================
  // HOW IT WORKS
  // =====================================================

  const renderHowItWorks = () => {
    return (
      <section
        id="how-it-works"
        className="how-section"
      >

        <div className="section-heading centered">

          <span className="section-label">
            SIMPLE BY DESIGN
          </span>

          <h2>
            Everything in three steps.
          </h2>

          <p>
            No queues. No paperwork. No confusion.
          </p>

        </div>

        <div className="steps">

          <div className="step">

            <div className="step-number">
              01
            </div>

            <h3>
              Discover
            </h3>

            <p>
              Browse upcoming campus events
              and find something worth attending.
            </p>

          </div>

          <div className="step-line" />

          <div className="step">

            <div className="step-number">
              02
            </div>

            <h3>
              Reserve
            </h3>

            <p>
              Check real-time seat availability
              and reserve your place instantly.
            </p>

          </div>

          <div className="step-line" />

          <div className="step">

            <div className="step-number">
              03
            </div>

            <h3>
              Attend
            </h3>

            <p>
              Your booking is stored securely.
              Just show up and enjoy the event.
            </p>

          </div>

        </div>

      </section>
    );
  };

  // =====================================================
  // FOOTER
  // =====================================================

  const renderFooter = () => {
    return (
      <footer>

        <div className="footer-inner">

          <div className="footer-brand">

            <div className="brand-mark">
              CP
            </div>

            <div>
              <strong>
                CampusPass
              </strong>

              <span>
                Built for better campus experiences.
              </span>
            </div>

          </div>

          <div className="footer-right">
            <span>
              CampusPass Platform
            </span>

            <span>•</span>

            <span>
              Microservices powered
            </span>
          </div>

        </div>

      </footer>
    );
  };

  // =====================================================
  // MAIN RETURN
  // =====================================================

  return (
    <div className="app">

      {renderNavbar()}

      <main>

        {/* GLOBAL MESSAGE */}

        {(message || error) && (
          <div
            style={{
              position: "fixed",
              top: "95px",
              left: "50%",
              transform: "translateX(-50%)",
              zIndex: 3000,
              padding: "12px 20px",
              borderRadius: "10px",
              background: error
                ? "#fff0f0"
                : "#eefbf5",
              color: error
                ? "#c0392b"
                : "#218c62",
              border: error
                ? "1px solid #ffd0d0"
                : "1px solid #c8f0df",
              fontSize: "13px",
              fontWeight: "600",
              boxShadow:
                "0 10px 30px rgba(0,0,0,0.1)",
            }}
          >
            {error || message}
          </div>
        )}

        {/* HOME */}

        {activeNav === "Home" &&
          renderHome()}

        {/* EVENTS */}

        {activeNav === "Events" &&
          renderEventsPage()}

        {/* MY BOOKINGS */}

        {activeNav === "My Bookings" &&
          renderBookingsPage()}

      </main>

      {renderFooter()}

      {/* =================================================
          BOOKING MODAL
          ================================================= */}

      {selectedEvent && (

        <div
          className="modal-overlay"
          onClick={() =>
            setSelectedEvent(null)
          }
        >

          <div
            className="booking-modal"
            onClick={(e) =>
              e.stopPropagation()
            }
          >

            <button
              className="close-modal"
              onClick={() =>
                setSelectedEvent(null)
              }
            >
              ×
            </button>

            <span className="section-label">
              RESERVE YOUR SEAT
            </span>

            <h2>
              {selectedEvent.name ||
                selectedEvent.title}
            </h2>

            <p>
              {selectedEvent.description}
            </p>

            <div className="modal-info">

              <div>
                <span>Date</span>
                <strong>
                  {selectedEvent.date}
                </strong>
              </div>

              <div>
                <span>Time</span>
                <strong>
                  {selectedEvent.time}
                </strong>
              </div>

              <div>
                <span>Venue</span>
                <strong>
                  {selectedEvent.venue}
                </strong>
              </div>

              <div>
                <span>Availability</span>
                <strong>
                  {selectedEvent.seats} seats
                </strong>
              </div>

            </div>

            <label>
              Student name
            </label>

            <input
              type="text"
              placeholder="Enter your name"
              value={studentName}
              onChange={(e) =>
                setStudentName(e.target.value)
              }
            />

            <button
              className="confirm-btn"
              onClick={handleBooking}
              disabled={
                bookingLoading ||
                selectedEvent.seats <= 0
              }
            >
              {bookingLoading
                ? "Booking..."
                : selectedEvent.seats > 0
                ? "Confirm Booking →"
                : "No Seats Available"}
            </button>

            <small className="modal-note">
              Seat availability is checked
              directly with the seat service.
            </small>

          </div>

        </div>

      )}

    </div>
  );
}

export default App;