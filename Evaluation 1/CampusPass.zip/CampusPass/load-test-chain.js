// CampusPass full-chain load test
// Each worker loops: POST /bookings (Booking -> Event -> Seat) then DELETE /bookings/:id
// (releases the seat so capacity never runs out). Only the POST is timed and counted.
// Docker stats are sampled once per second WHILE the load is running.
//
// Run:  node load-test-chain.js
// Output: console tables + results.json + results.csv

const { exec } = require("child_process");
const fs = require("fs");

const BASE_URL = "http://localhost:3003";
const WORKLOADS = [1, 2, 4, 8, 16];
const DURATION_MS = 10000;      // each workload runs this long
const PAUSE_MS = 3000;          // rest between workloads
const EVENT_IDS = [1, 2, 3];    // rotate over events

// ---------------------------------------------------------------
// docker stats sampling
// ---------------------------------------------------------------

function toMiB(text) {
  const m = /([\d.]+)\s*(B|KiB|MiB|GiB)/i.exec(text);
  if (!m) return 0;
  const v = parseFloat(m[1]);
  const unit = m[2].toLowerCase();
  if (unit === "gib") return v * 1024;
  if (unit === "mib") return v;
  if (unit === "kib") return v / 1024;
  return v / (1024 * 1024);
}

function readDockerStats() {
  return new Promise((resolve) => {
    exec(
      'docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"',
      (err, stdout) => {
        if (err) return resolve({});
        const out = {};
        stdout.trim().split("\n").forEach((line) => {
          const [name, cpu, mem] = line.split("|");
          if (!name) return;
          const key = ["event-service", "seat-service", "booking-service"].find((k) => name.includes(k));
          if (key) out[key] = { cpu: parseFloat(cpu), mem: toMiB(mem.split("/")[0]) };
        });
        resolve(out);
      }
    );
  });
}

async function sampleWhile(isRunning) {
  const samples = [];
  while (isRunning()) {
    const s = await readDockerStats();
    if (Object.keys(s).length) samples.push(s);
  }
  return samples;
}

function summarize(samples, svc) {
  const cpu = samples.map((s) => (s[svc] ? s[svc].cpu : 0));
  const mem = samples.map((s) => (s[svc] ? s[svc].mem : 0));
  const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
  return { cpuAvg: avg(cpu), cpuPeak: Math.max(0, ...cpu), memAvg: avg(mem) };
}

// ---------------------------------------------------------------
// one worker
// ---------------------------------------------------------------

async function worker(endAt, stats, id) {
  let i = id;
  while (performance.now() < endAt) {
    const eventId = EVENT_IDS[i++ % EVENT_IDS.length];
    const t0 = performance.now();
    try {
      const res = await fetch(`${BASE_URL}/bookings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentName: "LoadTest", eventId }),
      });
      const ms = performance.now() - t0;
      if (res.status === 201) {
        stats.ok++;
        stats.times.push(ms);
        const data = await res.json();
        // release the seat again (not timed, keeps capacity stable)
        try {
          const del = await fetch(`${BASE_URL}/bookings/${data.booking.id}`, { method: "DELETE" });
          if (!del.ok) stats.cleanupFailed++;
        } catch {
          stats.cleanupFailed++;
        }
      } else {
        stats.failed++;
        await res.text();
      }
    } catch {
      stats.failed++;
    }
  }
}

// ---------------------------------------------------------------
// run one workload
// ---------------------------------------------------------------

async function runWorkload(concurrency, index) {
  console.log(`\n=== W${index + 1}: ${concurrency} concurrent users, ${DURATION_MS / 1000}s ===`);
  const stats = { ok: 0, failed: 0, cleanupFailed: 0, times: [] };
  const start = performance.now();
  const endAt = start + DURATION_MS;
  let running = true;

  const sampler = sampleWhile(() => running);
  await Promise.all(Array.from({ length: concurrency }, (_, k) => worker(endAt, stats, k)));
  const elapsed = performance.now() - start;
  running = false;
  const samples = await sampler;

  const avgMs = stats.times.length ? stats.times.reduce((a, b) => a + b, 0) / stats.times.length : 0;
  const sorted = [...stats.times].sort((a, b) => a - b);
  const p95 = sorted.length ? sorted[Math.floor(sorted.length * 0.95) - 0] || sorted[sorted.length - 1] : 0;

  const r = {
    workload: `W${index + 1}`,
    concurrency,
    requests: stats.ok + stats.failed,
    successful: stats.ok,
    failed: stats.failed,
    avgResponseMs: +avgMs.toFixed(2),
    p95ResponseMs: +p95.toFixed(2),
    throughput: +((stats.ok / elapsed) * 1000).toFixed(2),
    cleanupFailed: stats.cleanupFailed,
    services: {},
  };
  for (const svc of ["booking-service", "seat-service", "event-service"]) {
    const s = summarize(samples, svc);
    r.services[svc] = { cpuAvg: +s.cpuAvg.toFixed(2), cpuPeak: +s.cpuPeak.toFixed(2), memMiB: +s.memAvg.toFixed(2) };
  }
  console.log(
    `ok=${r.successful} failed=${r.failed} avg=${r.avgResponseMs}ms p95=${r.p95ResponseMs}ms throughput=${r.throughput}/s samples=${samples.length}`
  );
  return r;
}

// ---------------------------------------------------------------
// main
// ---------------------------------------------------------------

async function main() {
  console.log("CAMPUSPASS FULL-CHAIN LOAD TEST  (POST /bookings -> Event + Seat)");

  // warm-up so the first workload is not penalised by cold start
  for (let i = 0; i < 5; i++) {
    const res = await fetch(`${BASE_URL}/bookings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentName: "WarmUp", eventId: 1 }),
    }).catch(() => null);
    if (res && res.status === 201) {
      const d = await res.json();
      await fetch(`${BASE_URL}/bookings/${d.booking.id}`, { method: "DELETE" });
    }
  }

  const results = [];
  for (let i = 0; i < WORKLOADS.length; i++) {
    results.push(await runWorkload(WORKLOADS[i], i));
    await new Promise((r) => setTimeout(r, PAUSE_MS));
  }

  const rows = results.map((r) => ({
    Workload: r.workload,
    Concurrency: r.concurrency,
    "Avg resp (ms)": r.avgResponseMs,
    "p95 (ms)": r.p95ResponseMs,
    "Throughput (req/s)": r.throughput,
    Failed: r.failed,
    "CPU booking %": r.services["booking-service"].cpuAvg,
    "CPU seat %": r.services["seat-service"].cpuAvg,
    "CPU event %": r.services["event-service"].cpuAvg,
    "Mem booking MiB": r.services["booking-service"].memMiB,
    "Mem seat MiB": r.services["seat-service"].memMiB,
    "Mem event MiB": r.services["event-service"].memMiB,
  }));

  console.log("\n=== FINAL OBSERVATION TABLE ===");
  console.table(rows);

  fs.writeFileSync("results.json", JSON.stringify(results, null, 2));
  const header = Object.keys(rows[0]).join(",");
  fs.writeFileSync("results.csv", [header, ...rows.map((r) => Object.values(r).join(","))].join("\n"));
  console.log("\nSaved results.json and results.csv");

  const leaked = results.reduce((a, r) => a + r.cleanupFailed, 0);
  if (leaked) console.log(`Warning: ${leaked} bookings could not be cancelled; restart containers to reset seats.`);
}

main();
