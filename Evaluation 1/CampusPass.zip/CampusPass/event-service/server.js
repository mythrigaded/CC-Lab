const express = require("express");

const app = express();

const PORT = 3001;

// =====================================================
// MIDDLEWARE
// =====================================================

app.use(express.json());

// -----------------------------------------------------
// CORS
// -----------------------------------------------------

app.use((req, res, next) => {
  res.header(
    "Access-Control-Allow-Origin",
    "http://localhost:5173"
  );

  res.header(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  );

  res.header(
    "Access-Control-Allow-Headers",
    "Content-Type"
  );

  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }

  next();
});

// =====================================================
// EVENT DATA
// =====================================================

const events = [
  {
    id: 1,
    name: "Tech Innovation Hackathon",
    category: "TECH",
    date: "2026-10-10",
    time: "9:00 AM",
    venue: "Innovation Centre",
    description:
      "Build, innovate and solve real-world problems with your team in our flagship campus hackathon.",
    seats: 100,
  },

  {
    id: 2,
    name: "Entrepreneurship Summit",
    category: "BUSINESS",
    date: "2026-10-15",
    time: "10:00 AM",
    venue: "Main Auditorium",
    description:
      "Meet founders, innovators and student entrepreneurs shaping the future.",
    seats: 200,
  },

  {
    id: 3,
    name: "AI & Future Technologies",
    category: "AI",
    date: "2026-10-21",
    time: "2:00 PM",
    venue: "Seminar Hall",
    description:
      "Explore artificial intelligence, edge computing and the technologies defining tomorrow.",
    seats: 150,
  },
];

// =====================================================
// HEALTH CHECK
// =====================================================

app.get("/", (req, res) => {
  res.json({
    service: "event-service",
    status: "running",
    port: PORT,
  });
});


// =====================================================
// GET ALL EVENTS
// =====================================================

app.get("/events", (req, res) => {
  res.json(events);
});


// =====================================================
// GET EVENT BY ID
// =====================================================

app.get("/events/:id", (req, res) => {
  const eventId = Number(req.params.id);

  const event = events.find(
    (item) => item.id === eventId
  );

  if (!event) {
    return res.status(404).json({
      message: "Event not found",
    });
  }

  res.json(event);
});


// =====================================================
// START SERVER
// =====================================================

app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `Event Service running on port ${PORT}`
  );
});