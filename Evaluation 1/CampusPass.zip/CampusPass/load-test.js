const { execSync } = require("child_process");

const API_URL = "http://localhost:3003/bookings";

const workloads = [1, 2, 4, 8, 16];


// =====================================================
// GET DOCKER STATS
// =====================================================

function getDockerStats() {

    try {

        const output = execSync(
            `docker stats --no-stream --format "{{.Name}}|{{.CPUPerc}}|{{.MemUsage}}"`
        ).toString().trim();

        const lines = output.split("\n");

        const services = {};

        lines.forEach(line => {

            const [name, cpu, memory] = line.split("|");

            if (
                name.includes("event-service") ||
                name.includes("seat-service") ||
                name.includes("booking-service")
            ) {

                services[name] = {
                    cpu,
                    memory
                };

            }

        });

        return services;

    } catch (error) {

        console.log("Unable to read Docker stats.");

        return {};

    }
}


// =====================================================
// SEND ONE REQUEST
// =====================================================

async function sendRequest() {

    const start = performance.now();

    try {

        const response = await fetch(API_URL);

        const end = performance.now();

        return {
            success: response.ok,
            time: end - start
        };

    } catch (error) {

        const end = performance.now();

        return {
            success: false,
            time: end - start
        };

    }
}


// =====================================================
// RUN WORKLOAD
// =====================================================

async function runWorkload(concurrency) {

    console.log("\n====================================");
    console.log(
        `WORKLOAD: ${concurrency} CONCURRENT REQUESTS`
    );
    console.log("====================================");


    // -----------------------------------------------
    // Docker stats BEFORE workload
    // -----------------------------------------------

    const beforeStats = getDockerStats();


    const startTime = performance.now();


    const requests = [];

    for (let i = 0; i < concurrency; i++) {

        requests.push(sendRequest());

    }


    const results = await Promise.all(requests);


    const endTime = performance.now();


    // -----------------------------------------------
    // Docker stats AFTER workload
    // -----------------------------------------------

    const afterStats = getDockerStats();


    const totalTime = endTime - startTime;


    const successful =
        results.filter(
            result => result.success
        ).length;


    const failed =
        results.length - successful;


    const averageResponseTime =
        results.reduce(
            (sum, result) =>
                sum + result.time,
            0
        ) / results.length;


    const throughput =
        (successful / totalTime) * 1000;


    console.log(
        `Successful Requests : ${successful}`
    );


    console.log(
        `Failed Requests     : ${failed}`
    );


    console.log(
        `Average Response    : ${averageResponseTime.toFixed(2)} ms`
    );


    console.log(
        `Total Test Time     : ${totalTime.toFixed(2)} ms`
    );


    console.log(
        `Throughput          : ${throughput.toFixed(2)} requests/sec`
    );


    console.log("\nDocker Statistics:");

    console.table(afterStats);


    return {

        workload:
            `W${workloads.indexOf(concurrency) + 1}`,

        concurrency,

        responseTime:
            averageResponseTime.toFixed(2),

        throughput:
            throughput.toFixed(2),

        failed,

        dockerStats:
            afterStats

    };

}


// =====================================================
// MAIN
// =====================================================

async function main() {

    console.log("\n");
    console.log("======================================");
    console.log(" CAMPUSPASS PERFORMANCE TEST");
    console.log("======================================");


    const results = [];


    for (const workload of workloads) {

        const result =
            await runWorkload(workload);


        results.push(result);


        // Give Docker a moment before next workload

        await new Promise(resolve =>
            setTimeout(resolve, 1500)
        );

    }


    console.log("\n");
    console.log("======================================");
    console.log(" FINAL RESULTS");
    console.log("======================================");


    console.table(
        results.map(result => ({

            Workload:
                result.workload,

            Concurrency:
                result.concurrency,

            "Response Time (ms)":
                result.responseTime,

            "Throughput (req/s)":
                result.throughput,

            "Failed Requests":
                result.failed

        }))
    );


    console.log("\n");
    console.log("======================================");
    console.log(" DOCKER RESOURCE OBSERVATIONS");
    console.log("======================================");


    results.forEach(result => {

        console.log(
            `\n${result.workload} - ${result.concurrency} concurrent requests`
        );

        console.table(result.dockerStats);

    });

}


main();