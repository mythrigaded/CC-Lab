const express = require("express");
const cors = require("cors");

const app = express();

const PORT = 3003;

// =====================================================
// MIDDLEWARE
// =====================================================

app.use(
  cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type"],
  })
);

app.use(express.json());


// =====================================================
// SERVICE URLS
// =====================================================

const EVENT_SERVICE_URL = "http://event-service:3001";
const SEAT_SERVICE_URL = "http://seat-service:3002";


// =====================================================
// BOOKING DATA
// =====================================================

let bookings = [];

let nextBookingId = 1;


// =====================================================
// HEALTH CHECK
// =====================================================

app.get("/", (req, res) => {
  res.json({
    service: "booking-service",
    status: "running",
    port: PORT,
  });
});


// =====================================================
// GET ALL BOOKINGS
// =====================================================

app.get("/bookings", (req, res) => {
  res.json(bookings);
});


// =====================================================
// GET BOOKING BY ID
// =====================================================

app.get("/bookings/:id", (req, res) => {
  const bookingId = Number(req.params.id);

  const booking = bookings.find(
    (item) => item.id === bookingId
  );

  if (!booking) {
    return res.status(404).json({
      message: "Booking not found",
    });
  }

  res.json(booking);
});


// =====================================================
// CREATE BOOKING
// =====================================================

app.post("/bookings", async (req, res) => {
  try {
    const { studentName, eventId } = req.body;

    // -------------------------------------------------
    // VALIDATION
    // -------------------------------------------------

    if (!studentName || !eventId) {
      return res.status(400).json({
        message: "Student name and event ID are required",
      });
    }

    const numericEventId = Number(eventId);

    // -------------------------------------------------
    // CHECK EVENT SERVICE
    // -------------------------------------------------

    let event;

    try {
      const response = await fetch(
        `${EVENT_SERVICE_URL}/events/${numericEventId}`
      );

      if (!response.ok) {
        return res.status(404).json({
          message: "Event not found",
        });
      }

      event = await response.json();
    } catch (error) {
      console.error("Event service error:", error);

      return res.status(503).json({
        message: "Event service unavailable",
      });
    }

    // -------------------------------------------------
    // CHECK SEAT SERVICE
    // -------------------------------------------------

    let seatData;

    try {
      const response = await fetch(
        `${SEAT_SERVICE_URL}/seats/${numericEventId}`
      );

      if (!response.ok) {
        return res.status(404).json({
          message: "Seat information not found",
        });
      }

      seatData = await response.json();
    } catch (error) {
      console.error("Seat service error:", error);

      return res.status(503).json({
        message: "Seat service unavailable",
      });
    }

    // -------------------------------------------------
    // CHECK AVAILABILITY
    // -------------------------------------------------

    if (seatData.availableSeats <= 0) {
      return res.status(409).json({
        message: "No seats available",
      });
    }

    // -------------------------------------------------
    // RESERVE SEAT
    // -------------------------------------------------

    try {
      const response = await fetch(
        `${SEAT_SERVICE_URL}/seats/${numericEventId}/reserve`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const result = await response.json();

      if (!response.ok) {
        return res.status(409).json({
          message:
            result.message || "Unable to reserve seat",
        });
      }

      seatData = result;
    } catch (error) {
      console.error("Seat reservation error:", error);

      return res.status(503).json({
        message: "Seat service unavailable",
      });
    }

    // -------------------------------------------------
    // CREATE BOOKING
    // -------------------------------------------------

    const newBooking = {
      id: nextBookingId++,

      studentName,

      eventId: numericEventId,

      eventName:
        event.name ||
        event.title ||
        "Campus Event",

      category: event.category || "EVENT",

      date: event.date || "",

      time: event.time || "",

      venue: event.venue || "",

      bookingDate: new Date().toISOString(),

      status: "Confirmed",

      seatsRemaining:
        seatData.availableSeats,
    };

    // -------------------------------------------------
    // SAVE BOOKING
    // -------------------------------------------------

    bookings.push(newBooking);

    // -------------------------------------------------
    // RETURN BOOKING
    // -------------------------------------------------

    return res.status(201).json({
      message: "Booking successful",

      booking: newBooking,

      availableSeats:
        seatData.availableSeats,
    });

  } catch (error) {
    console.error("Booking error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
});


// =====================================================
// CANCEL BOOKING
// =====================================================

app.delete("/bookings/:id", async (req, res) => {
  try {
    const bookingId = Number(req.params.id);

    // -------------------------------------------------
    // FIND BOOKING
    // -------------------------------------------------

    const index = bookings.findIndex(
      (booking) => booking.id === bookingId
    );

    if (index === -1) {
      return res.status(404).json({
        message: "Booking not found",
      });
    }

    const booking = bookings[index];

    // -------------------------------------------------
    // RELEASE SEAT
    // -------------------------------------------------

    try {
      const response = await fetch(
        `${SEAT_SERVICE_URL}/seats/${booking.eventId}/release`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const result = await response.json();

      if (!response.ok) {
        return res.status(409).json({
          message:
            result.message ||
            "Unable to release seat",
        });
      }

      // -------------------------------------------------
      // REMOVE BOOKING
      // -------------------------------------------------

      bookings.splice(index, 1);

      return res.json({
        message: "Booking cancelled successfully",

        booking,

        availableSeats:
          result.availableSeats,
      });

    } catch (error) {
      console.error(
        "Seat release error:",
        error
      );

      return res.status(503).json({
        message:
          "Seat service unavailable. Booking was not cancelled.",
      });
    }

  } catch (error) {
    console.error(
      "Cancellation error:",
      error
    );

    return res.status(500).json({
      message: "Internal server error",
    });
  }
});


// =====================================================
// START SERVER
// =====================================================

app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `Booking Service running on port ${PORT}`
  );
});