const express = require("express");
const cors = require("cors");

const app = express();

const PORT = 3002;


// =====================================================
// MIDDLEWARE
// =====================================================

app.use(
  cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type"],
  })
);

app.use(express.json());


// =====================================================
// SEAT DATA
// =====================================================

const seats = {
  1: {
    total: 100,
    available: 100,
  },

  2: {
    total: 200,
    available: 200,
  },

  3: {
    total: 150,
    available: 150,
  },
};


// =====================================================
// HOME / HEALTH CHECK
// =====================================================

app.get("/", (req, res) => {
  res.json({
    service: "seat-service",
    status: "running",
    port: PORT,
  });
});


app.get("/health", (req, res) => {
  res.json({
    service: "Seat Service",
    status: "running",
  });
});


// =====================================================
// GET SEAT INFORMATION
// =====================================================

app.get("/seats/:eventId", (req, res) => {
  const eventId = Number(req.params.eventId);

  if (!seats[eventId]) {
    return res.status(404).json({
      message: "Seat information not found",
    });
  }

  res.json({
    eventId: eventId,
    totalSeats: seats[eventId].total,
    availableSeats: seats[eventId].available,
  });
});


// =====================================================
// RESERVE ONE SEAT
// =====================================================

app.post("/seats/:eventId/reserve", (req, res) => {
  const eventId = Number(req.params.eventId);

  if (!seats[eventId]) {
    return res.status(404).json({
      message: "Event not found",
    });
  }

  if (seats[eventId].available <= 0) {
    return res.status(409).json({
      message: "No seats available",
    });
  }

  seats[eventId].available--;

  res.json({
    message: "Seat reserved successfully",
    eventId: eventId,
    totalSeats: seats[eventId].total,
    availableSeats: seats[eventId].available,
  });
});


// =====================================================
// RELEASE ONE SEAT
// =====================================================

app.post("/seats/:eventId/release", (req, res) => {
  const eventId = Number(req.params.eventId);

  if (!seats[eventId]) {
    return res.status(404).json({
      message: "Event not found",
    });
  }

  if (seats[eventId].available >= seats[eventId].total) {
    return res.status(400).json({
      message: "All seats are already available",
    });
  }

  seats[eventId].available++;

  res.json({
    message: "Seat released successfully",
    eventId: eventId,
    totalSeats: seats[eventId].total,
    availableSeats: seats[eventId].available,
  });
});


// =====================================================
// START SERVER
// =====================================================

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Seat Service running on port ${PORT}`);
});